import pandas as pd
import pickle
import numpy as np
from sklearn.metrics import mean_squared_error

# define function for mape
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

data_test = pd.read_csv('..\data\data_test.csv', parse_dates=['Date']).set_index('Date')
print(data_test.shape)
print(data_test.columns)

# repeat the same steps in test dataset
print('Feature selection')
# feature selection
basic_feature = ['date','stock_closing_usd']
sentiment_feature = ['sentiment_global_index', 'sentiment_global_count',
       'sentiment_finance_index', 'sentiment_finance_count']
stock_index_feature = ['DOW JONES COMPOSITE AVERAGE', 'DOW JONES INDUSTRIAL AVERAGE',
       'DOW JONES TRANSPORTATION AVERAGE', 'DOW JONES UTILITY AVERAGE',
       'S&P 500']
commodity_feature = ['NYMEX CRUDE OIL FUTURES', 'ICE BRENT CRUDE OIL FUTURES','NYMEX RBOB GASOLINE FUTURES']
# only consider relevant interest rate
interest_rate_feature= ['LONG-TERM INTEREST RATES_EURO AREA(19 COUNTRIES)', 'LONG-TERM INTEREST RATES_UNITED STATES', 'SHORT-TERM INTEREST RATES_EURO AREA(19 COUNTRIES)','SHORT-TERM INTEREST RATES_UNITED STATES']
outlook_feature = ['CRUDE OIL AND LIQUID FUELS SUPPLY_MILLION BARRELS PER DAY','CRUDE OIL INVENTORY (EXCLUDING SPR)_MILLION BARRELS, END-OF-PERIOD','IMPORTED  CRUDE OIL REAL PRICE_REAL DOLLARS PER BARREL','OPEC TOTAL CRUDE OIL PRODUCTION CAPACITY_MILLION BARRELS PER DAY','U.S. CRUDE OIL PRODUCTION_MILLION BARRELS PER DAY']
mobility_feature = ['DRIVING', 'TRANSIT', 'WALKING',
       'GROCERY AND PHARMACY PERCENT CHANGE FROM BASELINE',
       'PARKS PERCENT CHANGE FROM BASELINE',
       'RESIDENTIAL PERCENT CHANGE FROM BASELINE',
       'RETAIL AND RECREATION PERECENT CHANGE FROM BASELINE',
       'TRANSIT STATIONS PERCENT CHANGE FROM BASELINE',
       'WORKPLACES PERCENT CHANGE FROM BASELINE']
demand_feature = ['jodi_demand_kbd']

# selection groups of features
feature_to_shift = sentiment_feature + stock_index_feature + commodity_feature + interest_rate_feature + outlook_feature + mobility_feature
feature = basic_feature + feature_to_shift

data_test_subset = data_test[feature].sort_values('date')

print('Feature engineering')

data_test_subset_feature = data_test_subset[feature_to_shift].shift(1)
data_test_subset = pd.merge(data_test_subset['stock_closing_usd'],data_test_subset_feature,left_index=True, right_index=True)

# fill forward for monthly data
if len(set(data_test_subset.columns) & set(outlook_feature + demand_feature + interest_rate_feature))>0:
    for feature in set(data_test_subset.columns) & set(outlook_feature + demand_feature + interest_rate_feature):
        print('Filling forward for ', feature)
        data_test_subset[feature] = data_test_subset[feature].ffill()

# drop data points which mobility feature is na
data_test_subset = data_test_subset.dropna(subset=mobility_feature)

# fill na sentiment with 0
data_test_subset = data_test_subset.fillna(0)

# drop any remaining na
data_test_subset = data_test_subset.dropna()

# store cleaned test data
data_test_subset.to_csv('../data/data_test_cleaned.csv')


X = data_test_subset.drop(columns=['stock_closing_usd'])
y = data_test_subset['stock_closing_usd']
print(X.shape, y.shape)


# load the model from disk
filename = '../model/xgb.pkl'
model = pickle.load(open(filename, 'rb'))

y_pred = model.predict(X)

mse = mean_squared_error(y, y_pred)
rmse = mse**(1/2)
mape = mean_absolute_percentage_error(y, y_pred)

print('***************************************************\n',model)
print('MSE: ',mse)
print('RMSE: ',rmse)
print('MAPE: ', mape)

test_result = pd.DataFrame(np.array([y,y_pred]).transpose(), columns=['stock_closing_usd','pred_stock_closing_usd'], index=data_test_subset.index)
test_result = pd.merge(data_test_subset.drop(columns=['stock_closing_usd']),test_result,left_index=True, right_index=True)
test_result.to_csv('../result/model_prediction.csv')


