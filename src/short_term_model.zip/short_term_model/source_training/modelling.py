#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import seaborn as sn
import matplotlib.pyplot as plt
import pickle

from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.experimental import enable_hist_gradient_boosting
from sklearn.ensemble import HistGradientBoostingRegressor # faster than GradientBoostingRegressor
from sklearn.svm import SVR, LinearSVR
from sklearn.linear_model import SGDRegressor
from sklearn.metrics import mean_squared_error

from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.neural_network import MLPRegressor

import warnings
warnings.filterwarnings("ignore")


# In[2]:

# define function for mape
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100


# In[3]:

print('Data loading')

# load data
data = pd.read_csv('../data/data_2010_2021.csv', parse_dates=['Date']).set_index('Date')
data['date'] = data.index
# select only data from 2020 onwards due to availability of mobility data from 2020 onwards
data = data[data.date>='2020-01-01']
data = data[~data.stock_closing_usd.isna()]


# In[4]:

# split train and test data
data_train = data[data.index <= '2020-12-31']
data_train.to_csv('../data/data_train.csv')

data_test = data[data.index >= '2020-12-31'] # preserve the last date of the month to fillforward last month data for next month prediction
data_test.to_csv('../data/data_test.csv')


# In[6]:

print('Feature selection')

# feature selection
basic_feature = ['date','stock_closing_usd']
sentiment_feature = ['sentiment_global_index', 'sentiment_global_count',
       'sentiment_finance_index', 'sentiment_finance_count']
stock_index_feature = ['DOW JONES COMPOSITE AVERAGE', 'DOW JONES INDUSTRIAL AVERAGE',
       'DOW JONES TRANSPORTATION AVERAGE', 'DOW JONES UTILITY AVERAGE',
       'S&P 500']
commodity_feature = ['NYMEX CRUDE OIL FUTURES', 'ICE BRENT CRUDE OIL FUTURES','NYMEX RBOB GASOLINE FUTURES']
# only consider relevant interest rate
interest_rate_feature= ['LONG-TERM INTEREST RATES_EURO AREA(19 COUNTRIES)', 'LONG-TERM INTEREST RATES_UNITED STATES', 'SHORT-TERM INTEREST RATES_EURO AREA(19 COUNTRIES)','SHORT-TERM INTEREST RATES_UNITED STATES']
outlook_feature = ['CRUDE OIL AND LIQUID FUELS SUPPLY_MILLION BARRELS PER DAY','CRUDE OIL INVENTORY (EXCLUDING SPR)_MILLION BARRELS, END-OF-PERIOD','IMPORTED  CRUDE OIL REAL PRICE_REAL DOLLARS PER BARREL','OPEC TOTAL CRUDE OIL PRODUCTION CAPACITY_MILLION BARRELS PER DAY','U.S. CRUDE OIL PRODUCTION_MILLION BARRELS PER DAY']
mobility_feature = ['DRIVING', 'TRANSIT', 'WALKING',
       'GROCERY AND PHARMACY PERCENT CHANGE FROM BASELINE',
       'PARKS PERCENT CHANGE FROM BASELINE',
       'RESIDENTIAL PERCENT CHANGE FROM BASELINE',
       'RETAIL AND RECREATION PERECENT CHANGE FROM BASELINE',
       'TRANSIT STATIONS PERCENT CHANGE FROM BASELINE',
       'WORKPLACES PERCENT CHANGE FROM BASELINE']
demand_feature = ['jodi_demand_kbd'] # drop demand feature due to unavailability of data in 2021


# selection groups of features
feature_to_shift = sentiment_feature + stock_index_feature + commodity_feature + interest_rate_feature + outlook_feature + mobility_feature
feature = basic_feature + feature_to_shift

data_subset = data_train[feature].sort_values('date')


# In[8]:

print('Feature engineering')

# shift the features by 1: use yesterday data as feature to predict next day stock price
data_subset_feature = data_subset[feature_to_shift].shift(1)
data_subset = pd.merge(data_subset['stock_closing_usd'],data_subset_feature,left_index=True, right_index=True)

# feature engineering (no improvement in performance)
# data_subset['workplaces_percent_changes'] = data_subset['WORKPLACES PERCENT CHANGE FROM BASELINE'].diff()
# data_subset['driving_changes'] = data_subset['DRIVING'].diff()


# In[9]:

# fill forward for monthly data
if len(set(data_subset.columns) & set(outlook_feature + demand_feature + interest_rate_feature))>0:
    for feature in set(data_subset.columns) & set(outlook_feature + demand_feature + interest_rate_feature):
        print('Filling forward for ', feature)
        data_subset[feature] = data_subset[feature].ffill()


# In[10]:

# drop data points which mobility feature is na
data_subset = data_subset.dropna(subset=mobility_feature)

# fill na sentiment with 0
data_subset = data_subset.fillna(0)

# drop any remaining na
data_subset = data_subset.dropna()

# store cleaned training data
data_subset.to_csv('../data/data_train_cleaned.csv')


# In[15]:


X = data_subset.drop(columns=['stock_closing_usd'])
y = data_subset['stock_closing_usd']


# In[16]:


# # normalize variables (no improvement in performance, tree based model not requred scaling)
# X = preprocessing.normalize(data_subset[feature_to_shift])
# X


# In[18]:


# train-validation split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.20, shuffle=True)
print(X_train.shape, X_val.shape, y_train.shape, y_val.shape)


# In[19]:


model_dict = {
    'LR': LinearRegression(),
    'Ridge': Ridge(alpha=1.0),
    'Lasso': Lasso(alpha=0.1),
    'EN': ElasticNet(random_state=0),
    'DT': DecisionTreeRegressor(),
    'RF': RandomForestRegressor(),
    'GB': GradientBoostingRegressor(),
    'HGB': HistGradientBoostingRegressor(),
    'XGB': XGBRegressor(),
    # 'LGBM': LGBMRegressor(),
    'CB': CatBoostRegressor(verbose=0),
    'SVR': SVR(C=1.0, epsilon=0.2),
    'LSVR': LinearSVR(random_state=0, tol=1e-5),
    'SGD': SGDRegressor(max_iter=1000, tol=1e-3),
    'MLPR': MLPRegressor(random_state=1, max_iter=5000, solver='lbfgs', activation='relu')
    }


# In[20]:

print('Model training')

# train models
model_performance = pd.DataFrame(columns=['model','r2','mse','rmse','mape'])

for key, model_name in model_dict.items():

    model = model_name.fit(X_train, y_train)
    y_pred = model.predict(X_val)

    #evaluate performance
    r2 = model.score(X, y)
    mse = mean_squared_error(y_val, y_pred)
    rmse = mse**(1/2)
    mape = mean_absolute_percentage_error(y_val, y_pred)

    print('***************************************************\n',key)
    print('R2: ',r2)
    print('MSE: ',mse)
    print('RMSE: ',rmse)
    print('MAPE: ', mape)

    performance = pd.DataFrame(np.array([[model_name, r2, mse, rmse, mape]]), columns=['model','r2','mse','rmse','mape'])
    model_performance = model_performance.append(performance)

    # save model
    filename = '../model/'+key+'.pkl'
    pickle.dump(model, open(filename, 'wb'))

model_performance = model_performance.reset_index(drop=True)
model_performance.to_csv('../model/model_performance.csv', index=False)

print('Completed modelling')

# pd.DataFrame(np.array([y_val,y_pred]).transpose(), columns=['stock_closing_usd','pred_stock_closing_usd'])

# In[47]:


# # brute force:loop through combination of feature to get the best model
# from itertools import combinations 
# model_performance_combinations = pd.DataFrame(columns=['features','r2','mse','rmse','mape'])

# for i in range(1,len(feature_to_shift)):
# # for i in range(1,2):
#     # get all possible combinations
#     comb = combinations(feature_to_shift, i) 
#     counter = 0

#     for j in list(comb): 
        
#         counter+=1
#         print (i,' # combination - ',counter,' model') 

#         # prep data
#         data_subset_comb = data_subset[list(j)+['stock_closing_usd']]
#         X = data_subset_comb.drop(columns=['stock_closing_usd'])
#         y = data_subset_comb['stock_closing_usd']

#         X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, shuffle=True)
#         # print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)

#         # model training
#         model = XGBRegressor()
#         model = model.fit(X_train, y_train)
#         y_pred = model.predict(X_test)

#         # performance
#         r2 = model.score(X, y)
#         mse = mean_squared_error(y_test, y_pred)
#         rmse = mse**(1/2)
#         mape = mean_absolute_percentage_error(y_test, y_pred)

#         performance = pd.DataFrame(np.array([[j, r2, mse, rmse, mape]]), columns=['features','r2','mse','rmse','mape'])
#         model_performance_combinations = model_performance_combinations.append(performance)

# model_performance_combinations = model_performance_combinations.reset_index(drop=True)
# model_performance_combinations.to_csv('model_performance_combinations_xgboost.csv')

