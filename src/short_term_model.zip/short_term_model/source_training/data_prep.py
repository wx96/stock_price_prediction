#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


# focus on ExxonMobil
selected_ticker = 'XOM'


# In[3]:

# specify date range
data = pd.DataFrame(pd.date_range(start='2010-01-01', end='2021-02-28', closed=None), columns=['Date'])


# In[4]:

# data path
path_stock = '../data/full_dataset/stock_closing_nyse.csv'
path_sentiment_global = '../data/full_dataset/news-sentiment-index_global.csv' # keyword: exxon, oil, gas
path_sentiment_finance = '../data/full_dataset/news-sentiment-index_finance.csv' # keyword: exxon, oil, gas
path_stock_index = '../data/full_dataset/stock_index.csv'
path_price_commodity = '../data/full_dataset/price_commodity.csv' # filter: crude, gasoline, settle price
path_interest_rate = '../data/full_dataset/interest_rate.csv' # filter: monthly, exclude forecast
path_inventory_outlook = '../data/full_dataset/inventory_outlook.csv' # filter: crude, Us, monthly
path_jodi_demand = '../data/full_dataset/jodi_demand.csv' # filter: jodi, demand
path_mobility_apple = '../data/full_dataset/mobility_apple.csv' # filter: US, sub-region
path_mobility_google = '../data/full_dataset/mobility_google.csv' # filter: US


# In[5]:

# preping data
stock_nyse = pd.read_csv(path_stock, parse_dates=['Date Value'])
stock = stock_nyse[stock_nyse.Ticker == selected_ticker][['Date Value','Value']].rename(columns={'Value':'stock_closing_usd', 'Date Value':'Date'}).sort_values('Date')

sentiment_global = pd.read_csv(path_sentiment_global, parse_dates=['DateTime'])
sentiment_global = sentiment_global[['DateTime','Index','Count']].rename(columns={'DateTime':'Date','Index':'sentiment_global_index','Count':'sentiment_global_count'}).sort_values('Date')

sentiment_finance = pd.read_csv(path_sentiment_finance, parse_dates=['DateTime'])
sentiment_finance = sentiment_finance[['DateTime','Index','Count']].rename(columns={'DateTime':'Date','Index':'sentiment_finance_index','Count':'sentiment_finance_count'}).sort_values('Date')

stock_index = pd.read_csv(path_stock_index, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
stock_index = stock_index.pivot_table(index=['Date'], columns='Description', values='Value').reset_index()

price_commodity = pd.read_csv(path_price_commodity, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
price_commodity = price_commodity.pivot_table(index=['Date'], columns='Commodity And Exchange', values='Value').reset_index()

interest_rate = pd.read_csv(path_interest_rate, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
interest_rate['indicator_region'] = interest_rate['Indicator'] + '_' + interest_rate['Region']
interest_rate = interest_rate.pivot_table(index=['Date'], columns='indicator_region', values='Value').reset_index()

inventory_outlook = pd.read_csv(path_inventory_outlook, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
inventory_outlook['sector_unit'] = inventory_outlook['Sub-Sector Level 3'] + '_' + inventory_outlook['Unit']
inventory_outlook = inventory_outlook.pivot_table(index=['Date'], columns='sector_unit', values='Value').reset_index()

jodi_demand = pd.read_csv(path_jodi_demand, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
jodi_demand = jodi_demand.groupby(['Date'])['Value'].agg('sum').reset_index().rename(columns={'Value':'jodi_demand_kbd'})
jodi_demand

mobility_apple = pd.read_csv(path_mobility_apple, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
mobility_apple = mobility_apple.groupby(['Date','Transportation Type'])['Value'].agg('mean').reset_index()
mobility_apple = mobility_apple.pivot_table(index=['Date'], columns='Transportation Type', values='Value').reset_index()

mobility_google = pd.read_csv(path_mobility_google, parse_dates=['Date Value']).rename(columns={'Date Value':'Date'})
mobility_google = mobility_google.groupby(['Date','Indicator'])['Value'].agg('mean').reset_index()
mobility_google = mobility_google.pivot_table(index=['Date'], columns='Indicator', values='Value').reset_index()

# In[6]:


# merge data
data = pd.merge(data, stock, on = ['Date'], how='left')
data = pd.merge(data, sentiment_global, on = ['Date'], how='left')
data = pd.merge(data, sentiment_finance, on = ['Date'], how='left')
data = pd.merge(data, stock_index, on = ['Date'], how='left')
data = pd.merge(data, price_commodity, on = ['Date'], how='left')
data = pd.merge(data, interest_rate, on = ['Date'], how='left')
data = pd.merge(data, inventory_outlook, on = ['Date'], how='left')
data = pd.merge(data, jodi_demand, on = ['Date'], how='left')
data = pd.merge(data, mobility_apple, on = ['Date'], how='left')
data = pd.merge(data, mobility_google, on = ['Date'], how='left')
data.head(5)


# In[7]:

# write to file
data.to_csv('../data/data_2010_2021.csv', index=False)
print('Written consolidated data of ',data.shape)

