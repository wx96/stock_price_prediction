# ExxonMobil Next-Day Stock Price Prediction

## Table of Contents

- [About](#about)
- [Getting Started](#getting_started)

## About <a name = "about"></a>

This is a guide to utilize/run the short-term approach model. The model is built to predict ExxonMobil next-day stock price based on all today's feature value, which includes features from new sentiment, stock index, commodity futures, interest rate, outlook, and mobility index.

## Getting Started <a name = "getting_started"></a>

### Prerequisites

1. Install all the required packages as per requirements.txt

### Model Usage

The following steps are guide for user to get prediction for ExxonMobil next-day stock price using the pre-built model.

1. In file '..\short_term_model\source_test\run_prediction.py', key-in all required user inputs values from line #2 to line #31
* Note: Input today's data to predict for next-day stock price

```
# User to key-in today's data to get stock price prediction for the next day
sentiment_global_index	= -0.3
sentiment_global_count = 1
sentiment_finance_index = -0.4
sentiment_finance_count	= 1
DOW_JONES_COMPOSITE_AVERAGE = 10125.80
DOW_JONES_INDUSTRIAL_AVERAGE = 30686.45
DOW_JONES_TRANSPORTATION_AVERAGE = 12522.98
DOW_JONES_UTILITY_AVERAGE = 863.32
S_n_P_500	= 3826.31
NYMEX_CRUDE_OIL_FUTURES = 54.76	
ICE_BRENT_CRUDE_OIL_FUTURES	= 57.46
NYMEX_RBOB_GASOLINE_FUTURES	= 1.62
LONG_TERM_INTEREST_RATES_EURO_AREA_19_COUNTRIES = -0.09	
LONG_TERM_INTEREST_RATES_UNITED_STATES	= 0.93
SHORT_TERM_INTEREST_RATES_EURO_AREA_19_COUNTRIES = -0.54
SHORT_TERM_INTEREST_RATES_UNITED_STATES	= 0.17
CRUDE_OIL_AND_LIQUID_FUELS_SUPPLY_MILLION_BARRELS_PER_DAY = 21.51
CRUDE_OIL_INVENTORY_EXCLUDING_SPR_MILLION_BARRELS_END_OF_PERIOD = 494.39
IMPORTED_CRUDE_OIL_REAL_PRICE_REAL_DOLLARS_PER_BARREL = 52.34
OPEC_TOTAL_CRUDE_OIL_PRODUCTION_CAPACITY_MILLION_BARRELS_PER_DAY = 33.2	
US_CRUDE_OIL_PRODUCTION_MILLION_BARRELS_PER_DAY = 13.35
DRIVING	= 98.1
TRANSIT	= 58.07
WALKING	= 108.82
GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE = -32.59
PARKS_PERCENT_CHANGE_FROM_BASELINE = -34.39
RESIDENTIAL_PERCENT_CHANGE_FROM_BASELINE = 19.4	
RETAIL_AND_RECREATION_PERECENT_CHANGE_FROM_BASELINE	= -45.95
TRANSIT_STATIONS_PERCENT_CHANGE_FROM_BASELINE = -50.62
WORKPLACES_PERCENT_CHANGE_FROM_BASELINE	= -46.25
```

2. Save the changes.
3. In terminal, ensure the current working directory is in '..\short_term_model\source_test'.
4. Run
```
python run_prediction.py
```
5. The predicted ExxonMobil next-day stock price will be returned. 

### Model Training
The following steps are guide for user to run the model training.

1. In terminal, ensure the current working directory is in '..\short_term_model\source_training'.
2. Run
```
python main.py
```
### Descriptions of the scripts are as follow:
```
1. main.py      : source all the working files
2. data_prep.py : consolidate all data sources
3. modelling.py : preparation of features and training of models
4. scoring.py   : scoring of selected best model on test dataset
